// --- 0. HỆ THỐNG THÔNG BÁO TOAST ---
function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.position = 'fixed';
        container.style.top = '20px';
        container.style.right = '20px';
        container.style.zIndex = '9999';
        container.style.display = 'flex';
        container.style.flexDirection = 'column';
        container.style.alignItems = 'flex-end';
        document.body.prepend(container);
    }

    const toast = document.createElement('div');
    toast.style.background = '#fff';
    toast.style.minWidth = '250px';
    toast.style.maxWidth = 'calc(100vw - 40px)';
    toast.style.boxSizing = 'border-box';
    toast.style.padding = '15px 20px';
    toast.style.borderRadius = '8px';
    toast.style.boxShadow = '0 5px 15px rgba(0,0,0,0.15)';
    toast.style.marginBottom = '12px';
    toast.style.display = 'flex';
    toast.style.alignItems = 'center';
    toast.style.gap = '12px';
    toast.style.transition = 'all 0.4s ease';
    toast.style.transform = 'translateX(120%)';
    toast.style.opacity = '0';

    let icon = '🔔';
    let borderColor = '#3498db';
    if (type === 'success') { icon = '✅'; borderColor = '#27ae60'; }
    if (type === 'error') { icon = '❌'; borderColor = '#e74c3c'; }
    if (type === 'warning') { icon = '⚠️'; borderColor = '#f1c40f'; }

    toast.style.borderLeft = '6px solid ' + borderColor;
    toast.innerHTML = '<span style="font-size: 1.2em; flex-shrink: 0;">' + icon + '</span>' +
        '<span style="font-weight: 600; color: #2c3e50; word-break: break-word;">' + message + '</span>';

    container.appendChild(toast);

    setTimeout(() => { toast.style.transform = 'translateX(0)'; toast.style.opacity = '1'; }, 10);
    setTimeout(() => {
        toast.style.transform = 'translateX(120%)'; toast.style.opacity = '0';
        setTimeout(() => { toast.remove(); }, 400);
    }, 3000);
}

// --- 1. KIỂM TRA ĐĂNG NHẬP & HIỂN THỊ MENU ĐỒNG BỘ ---
function checkAuth() {
    const userStr = localStorage.getItem('user');
    const token = localStorage.getItem('token');

    if (!userStr || !token) {
        showToast("Vui lòng đăng nhập để tiến hành thanh toán!", "warning");
        setTimeout(() => { window.location.href = 'login.html'; }, 1500);
        return null;
    }

    const user = JSON.parse(userStr);
    const headerActions = document.querySelector('.header-actions');

    if (headerActions) {
        // Bơm CSS ép cứng cấu trúc (Xử lý menu ngang trên desktop và dropdown trên mobile)
        if (!document.getElementById('dynamic-menu-styles')) {
            const style = document.createElement('style');
            style.id = 'dynamic-menu-styles';
            style.innerHTML = `
                .header-container { display: flex !important; flex-direction: row !important; justify-content: space-between !important; align-items: center !important; flex-wrap: nowrap !important; }
                .header-actions { display: flex !important; align-items: center !important; position: relative !important; gap: 10px !important; }
                .menu-desktop-items { display: flex !important; align-items: center !important; gap: 15px !important; }
                .hamburger-btn { display: none !important; background: none; border: none; font-size: 28px; cursor: pointer; color: #333; }
                
                @media (max-width: 768px) {
                    .hamburger-btn { display: block !important; }
                    .user-greeting { display: none !important; } 
                    .menu-desktop-items {
                        display: none !important; 
                        position: absolute !important;
                        top: 50px !important; right: 0 !important;
                        background: white !important;
                        flex-direction: column !important;
                        padding: 20px !important;
                        border-radius: 12px !important;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important;
                        min-width: 220px !important;
                        z-index: 9999 !important;
                        gap: 15px !important;
                        border: 1px solid #f0f0f0 !important;
                    }
                    .menu-desktop-items.show { display: flex !important; }
                    .menu-desktop-items > * { width: 100% !important; text-align: center !important; margin: 0 !important; }
                }
            `;
            document.head.appendChild(style);
        }

        const greetingHTML = `<span class="user-greeting" style="font-size: 0.95em; color: #333; white-space: nowrap;">Xin chào, <b>${user.name}</b></span>`;

        const homeBtn = `<a href="index.html" style="text-decoration: none; padding: 8px 12px; border-radius: 8px; background: #f8f9fa; color: #007bff; border: 1px solid #e1e1e1; font-size: 0.9em; font-weight: bold; white-space: nowrap;">🏠 Trang chủ</a>`;

        let adminBtn = '';
        if (user.role === 'admin') {
            adminBtn = `<a href="admin.html" style="text-decoration: none; padding: 8px 12px; border-radius: 8px; background: #f8f9fa; color: #28a745; border: 1px solid #e1e1e1; font-size: 0.9em; font-weight: bold; white-space: nowrap;">⚙️ Admin</a>`;
        }

        const historyBtn = `<a href="history.html" style="text-decoration: none; padding: 8px 12px; border-radius: 8px; background: #f8f9fa; color: #17a2b8; border: 1px solid #e1e1e1; font-size: 0.9em; font-weight: bold; white-space: nowrap;">📦 Đơn hàng</a>`;

        // Nút Giỏ hàng (Blue Button) - Đặt lên trên Đăng xuất
        const cartHTML = `<a href="index.html" style="text-decoration: none; padding: 10px 18px; border-radius: 10px; background: #007bff; color: white; font-weight: bold; font-size: 0.9em; box-shadow: 0 3px 10px rgba(0,123,255,0.2); white-space: nowrap;">🛒 Giỏ hàng (<span id="header-cart-count">0</span>)</a>`;

        // Chữ Đăng xuất (Red Text) - Đặt dưới cùng
        const logoutBtn = `<a href="#" onclick="logout()" style="color: #dc3545; font-weight: bold; text-decoration: none; font-size: 0.95em; padding: 10px 0; display: block; white-space: nowrap;">Đăng xuất</a>`;

        headerActions.innerHTML = `
            ${greetingHTML}
            <button class="hamburger-btn" onclick="toggleMobileMenu()">☰</button>
            <div class="menu-desktop-items" id="nav-menu-items">
                ${homeBtn}
                ${adminBtn}
                ${historyBtn}
                ${cartHTML}
                ${logoutBtn}
            </div>
        `;
    }

    // Tự điền tên vào form
    const receiverNameInput = document.getElementById('receiver-name');
    if (receiverNameInput) receiverNameInput.value = user.name;

    return { user, token };
}

window.toggleMobileMenu = function () {
    const menu = document.getElementById('nav-menu-items');
    if (menu) menu.classList.toggle('show');
};

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    showToast("Đã đăng xuất!", "success");
    setTimeout(() => { window.location.href = 'index.html'; }, 1000);
}

// --- 2. LOAD GIỎ HÀNG RA GIAO DIỆN ---
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let totalPrice = 0;

function loadCheckoutCart() {
    // Cập nhật số lượng trên badge menu
    const countSpan = document.getElementById('header-cart-count');
    if (countSpan) {
        countSpan.innerText = cart.reduce((sum, i) => sum + i.quantity, 0);
    }

    if (cart.length === 0) {
        showToast("Giỏ hàng của bạn đang trống!", "warning");
        setTimeout(() => { window.location.href = 'index.html'; }, 1500);
        return;
    }

    const listContainer = document.getElementById('checkout-items-list');
    listContainer.innerHTML = '';
    totalPrice = 0;

    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        totalPrice += itemTotal;
        listContainer.innerHTML += `
            <div class="checkout-summary-item">
                <span><b>${item.quantity}x</b> ${item.name}</span>
                <strong>${itemTotal}$</strong>
            </div>
        `;
    });

    document.getElementById('checkout-total-price').innerText = totalPrice + '$';
}

// --- 3. XỬ LÝ GỬI ĐƠN HÀNG ---
async function submitOrder(event) {
    event.preventDefault();

    const authData = checkAuth();
    if (!authData) return;

    const receiver_name = document.getElementById('receiver-name').value;
    const phone = document.getElementById('receiver-phone').value;
    const address = document.getElementById('receiver-address').value;
    const btnSubmit = document.getElementById('btn-submit-order');

    const orderData = {
        receiver_name,
        phone,
        address,
        total_price: totalPrice,
        items: cart
    };

    try {
        btnSubmit.disabled = true;
        btnSubmit.innerText = "Đang xử lý...";

        const response = await fetch('http://localhost:3000/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authData.token}`
            },
            body: JSON.stringify(orderData)
        });

        const data = await response.json();

        if (response.ok) {
            showToast("🎉 Đặt hàng thành công! Mã đơn: #" + data.order_id, "success");
            localStorage.removeItem('cart');
            setTimeout(() => { window.location.href = 'index.html'; }, 2000);
        } else {
            showToast("Lỗi: " + data.error, "error");
            btnSubmit.disabled = false;
            btnSubmit.innerText = "Xác nhận đặt hàng";
        }
    } catch (error) {
        showToast("Không thể kết nối server!", "error");
        btnSubmit.disabled = false;
        btnSubmit.innerText = "Xác nhận đặt hàng";
    }
}

// Chạy khởi tạo
const authInfo = checkAuth();
loadCheckoutCart();