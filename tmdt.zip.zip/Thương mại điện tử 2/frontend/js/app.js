// --- 0. HỆ THỐNG THÔNG BÁO TOAST ---
function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.position = 'fixed';
        container.style.top = '20px';
        container.style.right = '20px';
        container.style.zIndex = '9999';
        container.style.display = 'flex';
        container.style.flexDirection = 'column';
        container.style.alignItems = 'flex-end';
        document.body.prepend(container);
    }

    const toast = document.createElement('div');
    toast.style.background = '#fff';
    toast.style.minWidth = '250px';
    toast.style.maxWidth = 'calc(100vw - 40px)';
    toast.style.boxSizing = 'border-box';
    toast.style.padding = '15px 20px';
    toast.style.borderRadius = '8px';
    toast.style.boxShadow = '0 5px 15px rgba(0,0,0,0.15)';
    toast.style.marginBottom = '12px';
    toast.style.display = 'flex';
    toast.style.alignItems = 'center';
    toast.style.gap = '12px';
    toast.style.transition = 'all 0.4s ease';
    toast.style.transform = 'translateX(120%)';
    toast.style.opacity = '0';

    let icon = '🔔';
    let borderColor = '#3498db';
    if (type === 'success') { icon = '✅'; borderColor = '#27ae60'; }
    if (type === 'error') { icon = '❌'; borderColor = '#e74c3c'; }
    if (type === 'warning') { icon = '⚠️'; borderColor = '#f1c40f'; }

    toast.style.borderLeft = '6px solid ' + borderColor;
    toast.innerHTML = '<span style="font-size: 1.2em; flex-shrink: 0;">' + icon + '</span>' +
        '<span style="font-weight: 600; color: #2c3e50; word-break: break-word;">' + message + '</span>';

    container.appendChild(toast);

    setTimeout(() => { toast.style.transform = 'translateX(0)'; toast.style.opacity = '1'; }, 10);
    setTimeout(() => {
        toast.style.transform = 'translateX(120%)'; toast.style.opacity = '0';
        setTimeout(() => { toast.remove(); }, 400);
    }, 3000);
}

// --- KHỞI TẠO GIỎ HÀNG TỪ LOCAL STORAGE ---
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// --- GIAO TIẾP VỚI BACKEND ---
async function fetchProducts() {
    try {
        const res = await fetch('http://localhost:3000/api/products');
        const products = await res.json();
        renderProducts(products);
    } catch (error) {
        console.error("Lỗi kết nối server, sử dụng dữ liệu giả:", error);
        renderProducts([
            { id: 1, name: "Lỗi kết nối Database", price: 0, image_url: "https://placehold.co/400x400?text=Error" },
        ]);
    }
}

// --- RENDER GIAO DIỆN SẢN PHẨM ---
function renderProducts(products) {
    const list = document.getElementById('home-product-list');
    if (!list) return;
    list.innerHTML = '';
    products.forEach(p => {
        list.innerHTML += `
            <div class="home-product-card">
                <img src="${p.image_url}" alt="${p.name}">
                <h4>${p.name}</h4>
                <p>${p.price}$</p>
                <button onclick="addToCart(${p.id}, '${p.name}', ${p.price})">Thêm vào giỏ</button>
            </div>
        `;
    });
}

// --- CÁC HÀM XỬ LÝ GIỎ HÀNG ---
function addToCart(id, name, price) {
    const item = cart.find(i => i.id === id);
    if (item) {
        item.quantity++;
    } else {
        cart.push({ id, name, price, quantity: 1 });
    }
    updateCartUI();
    showToast("Đã thêm " + name + " vào giỏ hàng!", "success");
}

function changeQuantity(id, delta) {
    const item = cart.find(i => i.id === id);
    if (item) {
        item.quantity += delta;
        if (item.quantity <= 0) {
            cart = cart.filter(i => i.id !== id);
        }
    }
    updateCartUI();
    renderCartModal();
}

function updateCartUI() {
    localStorage.setItem('cart', JSON.stringify(cart));
    const totalItems = cart.reduce((sum, i) => sum + i.quantity, 0);
    const countSpan = document.getElementById('header-cart-count');
    if (countSpan) countSpan.innerText = totalItems;
}

// --- CÁC HÀM XỬ LÝ MODAL (POPUP) GIỎ HÀNG ---
function viewCart() {
    const wrapper = document.getElementById('cart-modal-wrapper');
    if (wrapper) {
        wrapper.style.display = 'flex';
        renderCartModal();
    }
}

function closeCart() {
    const wrapper = document.getElementById('cart-modal-wrapper');
    if (wrapper) wrapper.style.display = 'none';
}

function renderCartModal() {
    const container = document.getElementById('cart-modal-items-container');
    if (!container) return;

    container.innerHTML = '';
    let total = 0;

    if (cart.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #888;">Giỏ hàng đang trống</p>';
    } else {
        cart.forEach(item => {
            total += item.price * item.quantity;
            container.innerHTML += `
                <div class="cart-modal-item-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; border-bottom: 1px dashed #eee; padding-bottom: 10px;">
                    <div>
                        <strong>${item.name}</strong> <br> 
                        <span style="color: #dc3545;">${item.price}$</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <button onclick="changeQuantity(${item.id}, -1)" style="padding: 5px 12px; cursor: pointer;">-</button>
                        <span style="font-weight: bold;">${item.quantity}</span>
                        <button onclick="changeQuantity(${item.id}, 1)" style="padding: 5px 12px; cursor: pointer;">+</button>
                    </div>
                </div>
            `;
        });
    }

    const totalSpan = document.getElementById('cart-modal-total-price');
    if (totalSpan) totalSpan.innerText = total;
}

function checkout() {
    if (cart.length === 0) {
        showToast("Giỏ hàng đang trống, hãy mua thêm đồ nhé!", "warning");
        return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
        showToast("Vui lòng đăng nhập trước khi thanh toán!", "warning");
        setTimeout(() => { window.location.href = 'login.html'; }, 1500);
        return;
    }

    window.location.href = 'checkout.html';
}

// --- KIỂM TRA ĐĂNG NHẬP & TẠO MENU RESPONSIVE ---
function checkLoginStatus() {
    const userStr = localStorage.getItem('user');
    const headerActions = document.querySelector('.header-actions');

    if (headerActions) {
        // Bơm CSS ép cứng cấu trúc (Xử lý menu ngang trên desktop và dropdown trên mobile)
        if (!document.getElementById('dynamic-menu-styles')) {
            const style = document.createElement('style');
            style.id = 'dynamic-menu-styles';
            style.innerHTML = `
                .header-container { display: flex !important; flex-direction: row !important; justify-content: space-between !important; align-items: center !important; flex-wrap: nowrap !important; }
                .header-actions { display: flex !important; align-items: center !important; position: relative !important; gap: 15px !important; }
                .menu-desktop-items { display: flex !important; align-items: center !important; gap: 12px !important; }
                .hamburger-btn { display: none !important; background: none; border: none; font-size: 28px; cursor: pointer; color: #333; }
                
                /* Avatar Header */
                .header-avatar { 
                    width: 38px; height: 38px; border-radius: 50%; object-fit: cover; 
                    cursor: pointer; border: 2px solid #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
                    transition: transform 0.2s;
                }
                .header-avatar:hover { transform: scale(1.08); border-color: #007bff; }

                @media (max-width: 768px) {
                    .hamburger-btn { display: block !important; }
                    .user-greeting { display: none !important; } 
                    .menu-desktop-items {
                        display: none !important; 
                        position: absolute !important;
                        top: 50px !important; right: 0 !important;
                        background: white !important;
                        flex-direction: column !important;
                        padding: 20px !important;
                        border-radius: 15px !important;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important;
                        min-width: 220px !important;
                        z-index: 9999 !important;
                        gap: 15px !important;
                        border: 1px solid #f0f0f0 !important;
                    }
                    .menu-desktop-items.show { display: flex !important; }
                    .menu-desktop-items > * { width: 100% !important; text-align: center !important; margin: 0 !important; }
                }
            `;
            document.head.appendChild(style);
        }

        let greetingHTML = '';
        let menuItemsHTML = '';
        let avatarHTML = '';

        if (userStr) {
            const user = JSON.parse(userStr);

            // Tạo ảnh đại diện (Nếu không có thì dùng icon mặc định)
            const avatarSrc = user.avatar || "https://placehold.co/100x100?text=👤";
            avatarHTML = `<a href="profile.html"><img src="${avatarSrc}" class="header-avatar" title="Hồ sơ cá nhân"></a>`;

            greetingHTML = `<span class="user-greeting" style="font-size: 0.95em; color: #333; white-space: nowrap;">Xin chào, <b>${user.name}</b></span>`;

            // Link Admin (nếu là admin)
            let adminBtn = '';
            if (user.role === 'admin') {
                adminBtn = `<a href="admin.html" style="text-decoration: none; padding: 8px 12px; border-radius: 8px; background: #f8f9fa; color: #28a745; border: 1px solid #e1e1e1; font-size: 0.9em; font-weight: bold; white-space: nowrap;">⚙️ Admin</a>`;
            }

            // Link Lịch sử đơn hàng
            const historyBtn = `<a href="history.html" style="text-decoration: none; padding: 8px 12px; border-radius: 8px; background: #f8f9fa; color: #17a2b8; border: 1px solid #e1e1e1; font-size: 0.9em; font-weight: bold; white-space: nowrap;">📦 Đơn hàng</a>`;

            // Nút Giỏ hàng
            const cartBtn = `<button class="header-cart-btn" onclick="viewCart()" style="background: #007bff; color: white; border: none; padding: 10px 18px; border-radius: 10px; cursor: pointer; font-weight: bold; font-size: 0.9em; box-shadow: 0 3px 10px rgba(0,123,255,0.2); white-space: nowrap;">🛒 Giỏ hàng (<span id="header-cart-count">0</span>)</button>`;

            // Chữ Đăng xuất
            const logoutBtn = `<a href="#" onclick="logout()" style="color: #dc3545; font-weight: bold; text-decoration: none; font-size: 0.95em; padding: 10px 0; display: block; white-space: nowrap;">Đăng xuất</a>`;

            // Mobile Only: Thêm mục Profile riêng vào Menu hamburger
            const profileMobileLink = `<a href="profile.html" class="mobile-only" style="font-weight: bold; color: #007bff; border-bottom: 1px solid #eee; padding-bottom: 10px;">👤 Hồ sơ cá nhân</a>`;

            menuItemsHTML = `${profileMobileLink} ${adminBtn} ${historyBtn} ${cartBtn} ${logoutBtn}`;
        } else {
            // Chưa đăng nhập
            const loginBtn = `<a href="login.html" style="color: #007bff; text-decoration: none; font-weight: bold; font-size: 0.95em; white-space: nowrap;">Đăng nhập</a>`;
            const registerBtn = `<a href="login.html" style="text-decoration: none; padding: 10px 18px; border-radius: 8px; background: #007bff; color: white; font-weight: bold; font-size: 0.9em; box-shadow: 0 2px 5px rgba(0,123,255,0.2); white-space: nowrap;">Đăng ký</a>`;
            const cartBtn = `<button class="header-cart-btn" onclick="viewCart()" style="background: #f8f9fa; color: #333; border: 1px solid #e1e1e1; padding: 10px 18px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 0.9em;">🛒 Giỏ hàng (<span id="header-cart-count">0</span>)</button>`;

            menuItemsHTML = `${loginBtn} ${registerBtn} ${cartBtn}`;
        }

        headerActions.innerHTML = `
            ${greetingHTML}
            ${avatarHTML}
            <button class="hamburger-btn" onclick="toggleMobileMenu()">☰</button>
            <div class="menu-desktop-items" id="nav-menu-items">
                ${menuItemsHTML}
            </div>
        `;
    }
}

window.toggleMobileMenu = function () {
    const menu = document.getElementById('nav-menu-items');
    if (menu) menu.classList.toggle('show');
};

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    showToast("Đã đăng xuất tài khoản!", "success");
    setTimeout(() => { window.location.reload(); }, 1000);
}

// --- CHẠY KHI MỞ TRANG ---
checkLoginStatus();
updateCartUI();
fetchProducts();