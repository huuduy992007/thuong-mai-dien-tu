// --- 0. HỆ THỐNG THÔNG BÁO TOAST ---
function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.position = 'fixed';
        container.style.top = '20px';
        container.style.right = '20px';
        container.style.zIndex = '9999';
        container.style.display = 'flex';
        container.style.flexDirection = 'column';
        container.style.alignItems = 'flex-end';
        document.body.prepend(container);
    }

    const toast = document.createElement('div');
    toast.style.background = '#fff';
    toast.style.minWidth = '250px';
    toast.style.maxWidth = 'calc(100vw - 40px)';
    toast.style.boxSizing = 'border-box';
    toast.style.padding = '15px 20px';
    toast.style.borderRadius = '8px';
    toast.style.boxShadow = '0 5px 15px rgba(0,0,0,0.15)';
    toast.style.marginBottom = '12px';
    toast.style.display = 'flex';
    toast.style.alignItems = 'center';
    toast.style.gap = '12px';
    toast.style.transition = 'all 0.4s ease';
    toast.style.transform = 'translateX(120%)';
    toast.style.opacity = '0';

    let icon = '🔔';
    let borderColor = '#3498db';
    if (type === 'success') { icon = '✅'; borderColor = '#27ae60'; }
    if (type === 'error') { icon = '❌'; borderColor = '#e74c3c'; }
    if (type === 'warning') { icon = '⚠️'; borderColor = '#f1c40f'; }

    toast.style.borderLeft = '6px solid ' + borderColor;
    toast.innerHTML = `<span style="font-size: 1.2em; flex-shrink: 0;">${icon}</span>` +
        `<span style="font-weight: 600; color: #2c3e50; word-break: break-word;">${message}</span>`;

    container.appendChild(toast);

    setTimeout(() => { toast.style.transform = 'translateX(0)'; toast.style.opacity = '1'; }, 10);
    setTimeout(() => {
        toast.style.transform = 'translateX(120%)'; toast.style.opacity = '0';
        setTimeout(() => { toast.remove(); }, 400);
    }, 3000);
}

// --- HÀM NÉN ẢNH TỰ ĐỘNG ---
const compressImage = (file, maxWidth = 1024, quality = 0.7) => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target.result;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                if (width > maxWidth) {
                    height = (maxWidth / width) * height;
                    width = maxWidth;
                }
                canvas.width = width; canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
        };
        reader.onerror = (err) => reject(err);
    });
};

// --- KIỂM TRA QUYỀN ADMIN ---
function checkAdminAuth() {
    const userStr = localStorage.getItem('user');
    const token = localStorage.getItem('token');
    if (!userStr || !token) { window.location.href = 'login.html'; return null; }
    try {
        const user = JSON.parse(userStr);
        if (user.role !== 'admin') { window.location.href = 'index.html'; return null; }
        return { user, token };
    } catch (e) {
        localStorage.clear();
        window.location.href = 'login.html';
        return null;
    }
}

const authData = checkAdminAuth();

// --- ĐIỀU HƯỚNG TAB ---
function switchTab(tabName) {
    document.querySelectorAll('section').forEach(s => s.classList.add('hidden'));
    document.querySelectorAll('.nav-menu a').forEach(a => a.classList.remove('active'));

    const targetSection = document.getElementById('section-' + tabName);
    const targetTab = document.getElementById('tab-' + tabName);

    if (targetSection) targetSection.classList.remove('hidden');
    if (targetTab) targetTab.classList.add('active');

    if (window.innerWidth <= 768) toggleSidebar();

    if (tabName === 'orders') loadOrders();
    if (tabName === 'products') loadProducts();
    if (tabName === 'users') loadUsers();
}

function toggleSidebar() {
    const sidebar = document.getElementById('admin-sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    if (sidebar) sidebar.classList.toggle('active');
    if (overlay) overlay.classList.toggle('active');
}

// --- 1. QUẢN LÝ ĐƠN HÀNG ---
async function loadOrders() {
    try {
        const res = await fetch('http://localhost:3000/api/admin/orders', {
            headers: { 'Authorization': `Bearer ${authData.token}` }
        });

        if (res.status === 401 || res.status === 403) {
            showToast("Phiên làm việc hết hạn, vui lòng đăng nhập lại", "error");
            return;
        }

        const orders = await res.json();
        const tbody = document.getElementById('admin-orders-list');
        if (!tbody) return;
        tbody.innerHTML = '';

        if (!orders || orders.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:20px;">Chưa có đơn hàng nào.</td></tr>';
            return;
        }

        orders.forEach(o => {
            let statusLabel = '';
            if (o.status === 'pending') statusLabel = '<span style="color:#f39c12; font-weight:bold;">Chờ duyệt</span>';
            else if (o.status === 'shipping') statusLabel = '<span style="color:#3498db; font-weight:bold;">Đang giao</span>';
            else if (o.status === 'done') statusLabel = '<span style="color:#27ae60; font-weight:bold;">Thành công</span>';

            tbody.innerHTML += `
                <tr>
                    <td>#${o.id}</td>
                    <td><b>${o.receiver_name}</b><br><small>${o.phone}</small></td>
                    <td>${o.total}$</td>
                    <td>${statusLabel}</td>
                    <td><button class="btn-view" onclick="openOrderDetails(${o.id})">Xem & Duyệt</button></td>
                </tr>
            `;
        });
    } catch (e) { showToast("Lỗi kết nối server đơn hàng", "error"); }
}

async function openOrderDetails(orderId) {
    try {
        const res = await fetch(`http://localhost:3000/api/orders/${orderId}`, {
            headers: { 'Authorization': `Bearer ${authData.token}` }
        });
        const order = await res.json();

        const modal = document.getElementById('user-orders-modal');
        document.getElementById('modal-user-name').innerText = "Chi tiết đơn hàng #" + order.id;

        const tableContainer = document.getElementById('modal-table-container');
        tableContainer.innerHTML = `
            <div style="background:#f9f9f9; padding:15px; border-radius:10px; margin-bottom:20px; line-height:1.6;">
                <p>📍 <b>Địa chỉ:</b> ${order.address}</p>
                <p>📞 <b>SĐT:</b> ${order.phone}</p>
                <div style="margin-top:15px; padding-top:15px; border-top:1px solid #ddd;">
                    <b>Cập nhật trạng thái:</b>
                    <select id="update-status-select" style="padding:8px; border-radius:5px; margin-left:10px;">
                        <option value="pending" ${order.status === 'pending' ? 'selected' : ''}>Chờ duyệt</option>
                        <option value="shipping" ${order.status === 'shipping' ? 'selected' : ''}>Đang giao hàng</option>
                        <option value="done" ${order.status === 'done' ? 'selected' : ''}>Đã hoàn thành</option>
                    </select>
                    <button onclick="updateOrderStatus(${order.id})" style="background:#28a745; color:white; border:none; padding:8px 15px; border-radius:5px; cursor:pointer; font-weight:bold; margin-left:10px;">Cập nhật</button>
                </div>
            </div>
            <table class="admin-table">
                <thead><tr><th>Sản phẩm</th><th>Ảnh</th><th>SL</th><th>Giá</th></tr></thead>
                <tbody>
                    ${order.items.map(item => `
                        <tr>
                            <td>${item.name}</td>
                            <td><img src="${item.image_url}" width="40" style="border-radius:4px; height:40px; object-fit:cover;"></td>
                            <td>${item.quantity}</td>
                            <td>${item.price_at_time}$</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        modal.classList.remove('hidden');
    } catch (e) { showToast("Không thể xem chi tiết đơn này", "error"); }
}

async function updateOrderStatus(orderId) {
    const newStatus = document.getElementById('update-status-select').value;
    try {
        const res = await fetch(`http://localhost:3000/api/admin/orders/${orderId}/status`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authData.token}`
            },
            body: JSON.stringify({ status: newStatus })
        });
        if (res.ok) {
            showToast("Đã cập nhật trạng thái đơn hàng!", "success");
            closeUserOrdersModal();
            loadOrders();
        }
    } catch (e) { showToast("Lỗi kết nối khi cập nhật", "error"); }
}

// --- 2. QUẢN LÝ SẢN PHẨM ---
async function handleAddProduct(event) {
    event.preventDefault();
    const btn = document.getElementById('btn-add-submit');
    try {
        btn.disabled = true; btn.innerText = "Đang xử lý ảnh...";
        const name = document.getElementById('prod-name').value;
        const price = document.getElementById('prod-price').value;
        const stock = document.getElementById('prod-stock').value;
        const fileInput = document.getElementById('prod-image-file');

        let image_url = "";
        if (fileInput.files.length > 0) {
            image_url = await compressImage(fileInput.files[0]);
        } else {
            showToast("Vui lòng chọn ảnh sản phẩm", "warning");
            btn.disabled = false; return;
        }

        const res = await fetch('http://localhost:3000/api/admin/products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + authData.token },
            body: JSON.stringify({ name, price, stock, image_url })
        });

        if (res.ok) {
            showToast("Đã thêm sản phẩm thành công!", "success");
            event.target.reset();
            loadProducts();
        } else {
            const err = await res.json();
            showToast("Lỗi: " + err.error, "error");
        }
    } catch (e) { showToast("Lỗi hệ thống hoặc ảnh quá lớn", "error"); }
    finally { btn.disabled = false; btn.innerText = "➕ Thêm vào cửa hàng"; }
}

async function loadProducts() {
    try {
        const res = await fetch('http://localhost:3000/api/products');
        const products = await res.json();
        const wrapper = document.getElementById('admin-product-list-wrapper');
        if (!wrapper) return;

        let html = '<h3 class="section-title">Sản phẩm hiện có</h3><div class="table-responsive"><table class="admin-table"><thead><tr><th>Ảnh</th><th>Tên</th><th>Giá</th><th>Kho</th><th>Hành động</th></tr></thead><tbody>';
        products.forEach(p => {
            const pData = btoa(unescape(encodeURIComponent(JSON.stringify(p))));
            html += `<tr>
                <td><img src="${p.image_url}" width="50" style="height:50px; object-fit:cover; border-radius:4px;"></td>
                <td><b>${p.name}</b></td>
                <td>${p.price}$</td>
                <td>${p.stock}</td>
                <td>
                    <button class="btn-view" onclick="openEditProductModal('${pData}')">Sửa</button> 
                    <button class="btn-delete" onclick="deleteProduct(${p.id})">Xóa</button>
                </td>
            </tr>`;
        });
        wrapper.innerHTML = html + '</tbody></table></div>';
    } catch (e) { showToast("Lỗi tải danh sách sản phẩm", "error"); }
}

function deleteProduct(id) {
    if (!confirm("Bạn có chắc chắn muốn xóa sản phẩm này?")) return;
    fetch(`http://localhost:3000/api/admin/products/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': 'Bearer ' + authData.token }
    }).then(res => {
        if (res.ok) {
            showToast("Đã xóa sản phẩm", "success");
            loadProducts();
        } else {
            showToast("Không thể xóa sản phẩm", "error");
        }
    });
}

// --- 3. QUẢN LÝ NGƯỜI DÙNG (CẬP NHẬT: PHÂN QUYỀN, KHÓA, LỊCH SỬ) ---
async function loadUsers() {
    try {
        const res = await fetch('http://localhost:3000/api/admin/users', {
            headers: { 'Authorization': `Bearer ${authData.token}` }
        });

        if (res.status === 403) {
            showToast("Bạn không có quyền thực hiện thao tác này", "error");
            return;
        }

        const users = await res.json();
        const tbody = document.getElementById('admin-users-list');
        if (!tbody) return;
        tbody.innerHTML = '';

        if (!users || users.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:20px;">Không tìm thấy người dùng nào.</td></tr>';
            return;
        }

        users.forEach(u => {
            const avatar = u.avatar || 'https://placehold.co/40x40?text=👤';
            tbody.innerHTML += `
                <tr>
                    <td>#${u.id}</td>
                    <td>
                        <div style="display:flex; align-items:center; gap:12px;">
                            <img src="${avatar}" width="40" height="40" style="border-radius:50%; object-fit:cover; border:1px solid #ddd;">
                            <div style="line-height:1.2;">
                                <b style="font-size:1.1em;">${u.name}</b><br>
                                <small style="color:#666;">${u.email}</small>
                            </div>
                        </div>
                    </td>
                    <td>
                        <select onchange="updateUserRole(${u.id}, this.value)" style="padding:5px; border-radius:4px;">
                            <option value="user" ${u.role === 'user' ? 'selected' : ''}>USER</option>
                            <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>ADMIN</option>
                        </select>
                    </td>
                    <td><b style="color:#2980b9">${u.balance || 0}$</b></td>
                    <td>${u.is_locked ? '<span style="color:#e74c3c; font-weight:bold;">Bị khóa</span>' : '<span style="color:#27ae60; font-weight:bold;">Hoạt động</span>'}</td>
                    <td>
                        <button class="btn-view" onclick="viewUserOrders(${u.id}, '${u.name}')" title="Xem lịch sử mua hàng">📦 Đơn hàng</button>
                        <button class="btn-lock" style="background:${u.is_locked ? '#27ae60' : '#f39c12'}" onclick="toggleUserLock(${u.id}, ${u.is_locked})">
                            ${u.is_locked ? 'Mở khóa' : 'Khóa'}
                        </button>
                    </td>
                </tr>
            `;
        });
    } catch (e) {
        console.error(e);
        const tbody = document.getElementById('admin-users-list');
        if (tbody) tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:20px; color:#e74c3c; font-weight:bold;">Không thể tải danh sách người dùng. Hãy kiểm tra Backend API.</td></tr>';
    }
}

// Hàm đổi quyền
async function updateUserRole(userId, newRole) {
    if (!confirm(`Xác nhận đổi quyền của thành viên này sang ${newRole.toUpperCase()}?`)) {
        loadUsers(); return;
    }
    try {
        const res = await fetch(`http://localhost:3000/api/admin/users/${userId}/role`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authData.token}` },
            body: JSON.stringify({ role: newRole })
        });
        if (res.ok) { showToast("Đã thay đổi quyền hạn thành công!", "success"); loadUsers(); }
    } catch (e) { showToast("Lỗi cập nhật quyền", "error"); }
}

// Hàm khóa tài khoản
async function toggleUserLock(userId, currentStatus) {
    const action = currentStatus ? "MỞ KHÓA" : "KHÓA";
    if (!confirm(`Bạn có chắc muốn ${action} tài khoản này?`)) return;

    try {
        const res = await fetch(`http://localhost:3000/api/admin/users/${userId}/lock`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authData.token}` },
            body: JSON.stringify({ is_locked: !currentStatus })
        });
        if (res.ok) { showToast(`Đã ${action} tài khoản thành công!`, "success"); loadUsers(); }
    } catch (e) { showToast("Lỗi thao tác khóa", "error"); }
}

// Hàm xem lịch sử đơn của member
async function viewUserOrders(userId, userName) {
    try {
        const res = await fetch(`http://localhost:3000/api/admin/users/${userId}/orders`, {
            headers: { 'Authorization': `Bearer ${authData.token}` }
        });
        const orders = await res.json();

        const modal = document.getElementById('user-orders-modal');
        document.getElementById('modal-user-name').innerText = "Lịch sử mua hàng: " + userName;

        const tableContainer = document.getElementById('modal-table-container');
        if (!orders || orders.length === 0) {
            tableContainer.innerHTML = '<p style="text-align:center; padding:30px;">Người dùng này chưa có đơn hàng nào.</p>';
        } else {
            tableContainer.innerHTML = `
                <table class="admin-table">
                    <thead><tr><th>Mã Đơn</th><th>Ngày đặt</th><th>Tổng tiền</th><th>Trạng thái</th><th>Thao tác</th></tr></thead>
                    <tbody>
                        ${orders.map(o => `
                            <tr>
                                <td>#${o.id}</td>
                                <td>${new Date(o.created_at).toLocaleDateString('vi-VN')}</td>
                                <td><b>${o.total}$</b></td>
                                <td>${o.status}</td>
                                <td><button class="btn-view" onclick="openOrderDetails(${o.id})">Chi tiết</button></td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;
        }
        modal.classList.remove('hidden');
    } catch (e) { showToast("Lỗi tải lịch sử đơn", "error"); }
}

// --- 4. ĐỒNG BỘ AVATAR ADMIN & HỒ SƠ ---
function syncAdminProfile() {
    const sidebarHeader = document.querySelector('.sidebar-header');
    if (sidebarHeader && authData.user) {
        const avatarSrc = authData.user.avatar || 'https://placehold.co/100x100?text=👤';
        sidebarHeader.innerHTML = `
            <div style="text-align:center; width:100%; padding: 10px 0;">
                <a href="profile.html">
                    <img src="${avatarSrc}" style="width:70px; height:70px; border-radius:50%; border:3px solid #3498db; object-fit:cover; margin-bottom:10px; cursor:pointer; box-shadow: 0 4px 10px rgba(0,0,0,0.2);" title="Hồ sơ cá nhân">
                </a>
                <h2 style="font-size:1.1em; color:white; margin:0; letter-spacing: 0.5px;">${authData.user.name}</h2>
                <small style="color:#bdc3c7; font-weight: 500;">Quản trị viên</small>
            </div>
        `;
    }
}

function closeUserOrdersModal() {
    const modal = document.getElementById('user-orders-modal');
    if (modal) modal.classList.add('hidden');
}

function logoutAdmin() {
    localStorage.clear();
    window.location.href = 'login.html';
}

// Khởi chạy khi vào trang
window.onload = function () {
    if (authData) {
        loadOrders();
        syncAdminProfile();
    }
};