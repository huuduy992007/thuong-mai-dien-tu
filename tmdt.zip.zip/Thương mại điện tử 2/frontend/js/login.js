// --- 0. HỆ THỐNG THÔNG BÁO TOAST ---
function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.position = 'fixed';
        container.style.top = '20px';
        container.style.right = '20px';
        container.style.zIndex = '9999';
        document.body.prepend(container);
    }

    const toast = document.createElement('div');
    toast.style.background = '#fff';
    toast.style.minWidth = '280px';
    toast.style.padding = '15px 20px';
    toast.style.borderRadius = '8px';
    toast.style.boxShadow = '0 5px 15px rgba(0,0,0,0.15)';
    toast.style.marginBottom = '12px';
    toast.style.display = 'flex';
    toast.style.alignItems = 'center';
    toast.style.gap = '12px';
    toast.style.transition = 'all 0.4s ease';
    toast.style.transform = 'translateX(120%)';
    toast.style.opacity = '0';

    let icon = '🔔';
    let borderColor = '#3498db';
    if (type === 'success') { icon = '✅'; borderColor = '#27ae60'; }
    if (type === 'error') { icon = '❌'; borderColor = '#e74c3c'; }
    if (type === 'warning') { icon = '⚠️'; borderColor = '#f1c40f'; }

    toast.style.borderLeft = '6px solid ' + borderColor;

    // Nối chuỗi truyền thống để chống lỗi
    toast.innerHTML = '<span style="font-size: 1.2em;">' + icon + '</span>' +
        '<span style="font-weight: 600; color: #2c3e50;">' + message + '</span>';

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.transform = 'translateX(0)';
        toast.style.opacity = '1';
    }, 10);

    setTimeout(() => {
        toast.style.transform = 'translateX(120%)';
        toast.style.opacity = '0';
        setTimeout(() => { toast.remove(); }, 400);
    }, 3000);
}

// --- CHUYỂN ĐỔI GIỮA FORM ĐĂNG NHẬP / ĐĂNG KÝ ---
function toggleAuthForm(type) {
    const loginBox = document.getElementById('login-form-box');
    const registerBox = document.getElementById('register-form-box');

    if (type === 'register') {
        loginBox.classList.add('hidden');
        registerBox.classList.remove('hidden');
    } else {
        registerBox.classList.add('hidden');
        loginBox.classList.remove('hidden');
    }
}

// --- XỬ LÝ ĐĂNG KÝ ---
async function handleRegister(event) {
    event.preventDefault();

    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const btnSubmit = event.target.querySelector('button[type="submit"]');

    try {
        btnSubmit.innerText = "Đang xử lý...";
        btnSubmit.disabled = true;

        const response = await fetch('http://localhost:3000/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password })
        });

        const data = await response.json();

        if (response.ok) {
            // Thay thế alert bằng showToast
            showToast("Đăng ký thành công! Đang chuyển sang form Đăng Nhập...", "success");

            document.getElementById('register-form').reset();

            // Đợi 1.5 giây để người dùng kịp đọc thông báo rồi mới chuyển form
            setTimeout(() => {
                toggleAuthForm('login');
                btnSubmit.innerText = "Đăng ký";
                btnSubmit.disabled = false;
            }, 1500);

        } else {
            showToast("Lỗi: " + data.error, "error");
            btnSubmit.innerText = "Đăng ký";
            btnSubmit.disabled = false;
        }
    } catch (error) {
        console.error(error);
        showToast("Không thể kết nối tới server!", "error");
        btnSubmit.innerText = "Đăng ký";
        btnSubmit.disabled = false;
    }
}

// --- XỬ LÝ ĐĂNG NHẬP ---
async function handleLogin(event) {
    event.preventDefault();

    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const btnSubmit = event.target.querySelector('button[type="submit"]');

    try {
        btnSubmit.innerText = "Đang kiểm tra...";
        btnSubmit.disabled = true;

        const response = await fetch('http://localhost:3000/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (response.ok) {
            // Thay thế alert bằng showToast
            showToast("Đăng nhập thành công!", "success");

            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));

            setTimeout(() => {
                if (data.user.role === 'admin') {
                    window.location.href = 'admin.html';
                } else {
                    window.location.href = 'index.html';
                }
            }, 1000);

        } else {
            showToast("Lỗi: " + data.error, "error");
            btnSubmit.innerText = "Đăng nhập";
            btnSubmit.disabled = false;
        }
    } catch (error) {
        console.error(error);
        showToast("Không thể kết nối tới server!", "error");
        btnSubmit.innerText = "Đăng nhập";
        btnSubmit.disabled = false;
    }
}