const mysql = require('mysql2');
const bcrypt = require('bcrypt');

// Cấu hình kết nối MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '' // Mặc định XAMPP để trống
});

connection.connect((err) => {
    if (err) {
        console.error("❌ Lỗi kết nối MySQL:", err.message);
        return;
    }
    console.log("🚀 Đã kết nối tới MySQL!");

    // Tạo Database nếu chưa có
    connection.query("CREATE DATABASE IF NOT EXISTS mini_ecommerce", (err) => {
        if (err) throw err;
        connection.changeUser({ database: 'mini_ecommerce' }, (err) => {
            if (err) throw err;

            // Xóa các bảng cũ theo thứ tự ràng buộc khóa ngoại
            const dropQueries = [
                "DROP TABLE IF EXISTS order_items",
                "DROP TABLE IF EXISTS orders",
                "DROP TABLE IF EXISTS products",
                "DROP TABLE IF EXISTS users"
            ];

            console.log("🧹 Đang làm sạch dữ liệu cũ...");
            let dropCount = 0;
            dropQueries.forEach(q => {
                connection.query(q, () => {
                    dropCount++;
                    if (dropCount === dropQueries.length) createTables();
                });
            });
        });
    });
});

function createTables() {
    console.log("🛠️ Đang tạo cấu trúc bảng mới...");

    // 1. Bảng Users (Hỗ trợ Profile, Wallet, OTP)
    const q1 = `CREATE TABLE users (
        id INT AUTO_INCREMENT PRIMARY KEY, 
        name VARCHAR(255) NOT NULL, 
        email VARCHAR(255) UNIQUE NOT NULL, 
        password_hash VARCHAR(255),
        role VARCHAR(50) DEFAULT 'user',
        avatar LONGTEXT,
        balance FLOAT DEFAULT 0,
        reset_otp VARCHAR(10),
        otp_expiry DATETIME,
        is_locked BOOLEAN DEFAULT FALSE
    )`;

    // 2. Bảng Products (Ảnh LONGTEXT để lưu Base64)
    const q2 = `CREATE TABLE products (
        id INT AUTO_INCREMENT PRIMARY KEY, 
        name VARCHAR(255) NOT NULL, 
        price FLOAT NOT NULL, 
        image_url LONGTEXT, 
        stock INT DEFAULT 0
    )`;

    // 3. Bảng Orders (Hỗ trợ ví tiền)
    const q3 = `CREATE TABLE orders (
        id INT AUTO_INCREMENT PRIMARY KEY, 
        user_id INT, 
        receiver_name VARCHAR(255), 
        phone VARCHAR(20), 
        address TEXT, 
        total FLOAT, 
        payment_method VARCHAR(50) DEFAULT 'COD',
        status VARCHAR(50) DEFAULT 'pending', 
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`;

    // 4. Bảng Order Items
    const q4 = `CREATE TABLE order_items (
        id INT AUTO_INCREMENT PRIMARY KEY, 
        order_id INT, 
        product_id INT, 
        quantity INT, 
        price_at_time FLOAT,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )`;

    connection.query(q1, () => {
        connection.query(q2, () => {
            connection.query(q3, () => {
                connection.query(q4, () => {
                    console.log("✅ Đã tạo xong 4 bảng.");
                    insertData();
                });
            });
        });
    });
}

function insertData() {
    console.log("📝 Đang nạp dữ liệu mẫu...");
    const hash = bcrypt.hashSync('admin123', 10);

    // Nạp Admin và User mẫu (User có sẵn 5000$ để test ví)
    const userQuery = `INSERT INTO users (name, email, password_hash, role, balance) VALUES 
        ('Quản trị viên', 'admin@shop.com', ?, 'admin', 0),
        ('Người dùng mẫu', 'user@test.com', ?, 'user', 5000)`;

    connection.query(userQuery, [hash, hash], (err) => {
        if (err) throw err;

        // Nạp sản phẩm mẫu
        const productQuery = `INSERT INTO products (name, price, image_url, stock) VALUES 
            ('AirPods Pro 2', 250, 'https://placehold.co/400x400?text=AirPods', 50),
            ('MacBook Pro M3', 2500, 'https://placehold.co/400x400?text=MacBook', 20),
            ('Samsung S24 Ultra', 1100, 'https://placehold.co/400x400?text=S24', 30)`;

        connection.query(productQuery, (err) => {
            if (err) throw err;
            console.log("🎉 KHỞI TẠO THÀNH CÔNG! Hãy chạy: node server.js");
            connection.end();
            process.exit(0);
        });
    });
}