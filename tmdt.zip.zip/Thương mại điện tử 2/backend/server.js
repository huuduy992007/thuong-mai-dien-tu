const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());

// --- CẤU HÌNH QUAN TRỌNG: Cho phép nhận dữ liệu ảnh Base64 lớn (10MB) ---
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', // Mặc định XAMPP để trống
    database: 'mini_ecommerce'
});

db.connect((err) => {
    if (err) console.error("❌ Lỗi kết nối Database:", err.message);
    else console.log("✅ Đã kết nối Database: mini_ecommerce");
});

const SECRET_KEY = "my_secret_key_super_safe";

// --- MIDDLEWARE XÁC THỰC TOKEN ---
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.status(401).json({ error: "Vui lòng đăng nhập lại" });

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.status(403).json({ error: "Phiên làm việc hết hạn" });
        req.user = user;
        next();
    });
};

// --- 1. HỆ THỐNG AUTH (ĐĂNG NHẬP / ĐĂNG KÝ) ---

app.post('/api/auth/register', (req, res) => {
    const { name, email, password } = req.body;
    const hash = bcrypt.hashSync(password, 10);
    db.query("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
        [name, email, hash], (err) => {
            if (err) return res.status(400).json({ error: "Email này đã được sử dụng" });
            res.json({ message: "Đăng ký thành công" });
        });
});

app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    db.query("SELECT * FROM users WHERE email = ?", [email], (err, results) => {
        if (err) return res.status(500).json({ error: "Lỗi máy chủ" });
        const user = results[0];

        if (!user || !bcrypt.compareSync(password, user.password_hash)) {
            return res.status(401).json({ error: "Sai tài khoản hoặc mật khẩu" });
        }

        if (user.is_locked) {
            return res.status(403).json({ error: "Tài khoản đã bị khóa, vui lòng liên hệ admin!" });
        }

        const token = jwt.sign({ id: user.id, role: user.role }, SECRET_KEY, { expiresIn: '24h' });
        res.json({
            token,
            user: { id: user.id, name: user.name, role: user.role, avatar: user.avatar, balance: user.balance }
        });
    });
});

// --- 2. API QUẢN TRỊ NGƯỜI DÙNG (ADMIN ONLY) ---

app.get('/api/admin/users', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Không có quyền" });
    db.query("SELECT id, name, email, role, balance, avatar, is_locked FROM users", (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

app.put('/api/admin/users/:id/role', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Không có quyền" });
    const { role } = req.body;
    db.query("UPDATE users SET role = ? WHERE id = ?", [role, req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Đã cập nhật quyền hạn" });
    });
});

app.put('/api/admin/users/:id/lock', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Không có quyền" });
    const { is_locked } = req.body;
    db.query("UPDATE users SET is_locked = ? WHERE id = ?", [is_locked, req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Cập nhật trạng thái thành công" });
    });
});

app.get('/api/admin/users/:id/orders', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Không có quyền" });
    db.query("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC", [req.params.id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

// --- 3. API HỒ SƠ & VÍ TIỀN (USER) ---

app.get('/api/user/profile', authenticateToken, (req, res) => {
    db.query("SELECT id, name, email, avatar, balance, role FROM users WHERE id = ?", [req.user.id], (err, results) => {
        if (err || results.length === 0) return res.status(404).json({ error: "Không tìm thấy người dùng" });
        res.json(results[0]);
    });
});

app.put('/api/user/update', authenticateToken, (req, res) => {
    const { name, avatar, new_password } = req.body;
    let query = "UPDATE users SET name = ?, avatar = ? WHERE id = ?";
    let params = [name, avatar, req.user.id];

    if (new_password && new_password.trim() !== "") {
        const hash = bcrypt.hashSync(new_password, 10);
        query = "UPDATE users SET name = ?, avatar = ?, password_hash = ? WHERE id = ?";
        params = [name, avatar, hash, req.user.id];
    }

    db.query(query, params, (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Cập nhật hồ sơ thành công" });
    });
});

app.post('/api/user/topup', authenticateToken, (req, res) => {
    const { amount } = req.body;
    if (!amount || amount <= 0) return res.status(400).json({ error: "Số tiền không hợp lệ" });
    db.query("UPDATE users SET balance = balance + ? WHERE id = ?", [amount, req.user.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Nạp tiền thành công" });
    });
});

// --- 4. API SẢN PHẨM ---

app.get('/api/products', (req, res) => {
    db.query("SELECT * FROM products", (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

app.post('/api/admin/products', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Không có quyền" });
    const { name, price, image_url, stock } = req.body;
    db.query("INSERT INTO products (name, price, image_url, stock) VALUES (?, ?, ?, ?)",
        [name, price, image_url, stock], (err) => {
            if (err) return res.status(500).json({ error: "Lỗi lưu sản phẩm (có thể do ảnh quá lớn)" });
            res.json({ message: "Đã thêm sản phẩm" });
        });
});

app.delete('/api/admin/products/:id', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Không có quyền" });
    db.query("DELETE FROM products WHERE id = ?", [req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Đã xóa sản phẩm" });
    });
});

// --- 5. API ĐƠN HÀNG ---

app.get('/api/admin/orders', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Không có quyền" });
    db.query("SELECT * FROM orders ORDER BY id DESC", (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

app.put('/api/admin/orders/:id/status', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: "Không có quyền" });
    const { status } = req.body;
    db.query("UPDATE orders SET status = ? WHERE id = ?", [status, req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Cập nhật thành công" });
    });
});

app.post('/api/orders', authenticateToken, (req, res) => {
    const { receiver_name, phone, address, total_price, items, use_wallet } = req.body;

    const processOrder = (paymentMethod) => {
        db.query("INSERT INTO orders (user_id, receiver_name, phone, address, total, payment_method) VALUES (?, ?, ?, ?, ?, ?)",
            [req.user.id, receiver_name, phone, address, total_price, paymentMethod], (err, result) => {
                if (err) {
                    // XỬ LÝ LỖI FOREIGN KEY (Xảy ra khi ID người dùng không tồn tại)
                    if (err.code === 'ER_NO_REFERENCED_ROW_2') {
                        return res.status(401).json({ error: "Dữ liệu tài khoản đã bị thay đổi (Seed reset). Vui lòng ĐĂNG XUẤT và ĐĂNG NHẬP LẠI để tiếp tục." });
                    }
                    return res.status(500).json({ error: "Lỗi lưu đơn hàng: " + err.message });
                }
                const orderId = result.insertId;
                items.forEach(item => {
                    db.query("INSERT INTO order_items (order_id, product_id, quantity, price_at_time) VALUES (?, ?, ?, ?)",
                        [orderId, item.id, item.quantity, item.price]);
                });
                res.json({ message: "Đặt hàng thành công", order_id: orderId });
            });
    };

    if (use_wallet) {
        db.query("SELECT balance FROM users WHERE id = ?", [req.user.id], (err, results) => {
            if (err || results.length === 0) return res.status(404).json({ error: "Người dùng không tồn tại" });
            if (results[0].balance < total_price) return res.status(400).json({ error: "Số dư ví không đủ" });
            db.query("UPDATE users SET balance = balance - ? WHERE id = ?", [total_price, req.user.id], () => processOrder('Wallet'));
        });
    } else {
        processOrder('COD');
    }
});

app.get('/api/orders/me', authenticateToken, (req, res) => {
    db.query("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC", [req.user.id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

app.get('/api/orders/:id', authenticateToken, (req, res) => {
    db.query("SELECT * FROM orders WHERE id = ?", [req.params.id], (err, orderResults) => {
        if (err) return res.status(500).json({ error: err.message });
        const order = orderResults[0];
        if (!order) return res.status(404).json({ error: "Không tìm thấy đơn" });

        if (req.user.role !== 'admin' && order.user_id !== req.user.id) {
            return res.status(403).json({ error: "Bạn không có quyền xem đơn này" });
        }

        const itemsQuery = `SELECT oi.quantity, oi.price_at_time, p.name, p.image_url FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?`;
        db.query(itemsQuery, [req.params.id], (err, itemsResults) => {
            res.json({ ...order, items: itemsResults });
        });
    });
});

const PORT = 3000;
app.listen(PORT, () => console.log(`🚀 Server đang chạy tại http://localhost:${PORT}`));