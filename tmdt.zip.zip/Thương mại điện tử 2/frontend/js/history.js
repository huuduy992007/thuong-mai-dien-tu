// --- 0. HỆ THỐNG THÔNG BÁO TOAST ---
function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.position = 'fixed';
        container.style.top = '20px';
        container.style.right = '20px';
        container.style.zIndex = '9999';
        container.style.display = 'flex';
        container.style.flexDirection = 'column';
        container.style.alignItems = 'flex-end';
        document.body.prepend(container);
    }

    const toast = document.createElement('div');
    toast.style.background = '#fff';
    toast.style.minWidth = '250px';
    toast.style.maxWidth = 'calc(100vw - 40px)';
    toast.style.boxSizing = 'border-box';
    toast.style.padding = '15px 20px';
    toast.style.borderRadius = '8px';
    toast.style.boxShadow = '0 5px 15px rgba(0,0,0,0.15)';
    toast.style.marginBottom = '12px';
    toast.style.display = 'flex';
    toast.style.alignItems = 'center';
    toast.style.gap = '12px';
    toast.style.transition = 'all 0.4s ease';
    toast.style.transform = 'translateX(120%)';
    toast.style.opacity = '0';

    let icon = '🔔';
    let borderColor = '#3498db';
    if (type === 'success') { icon = '✅'; borderColor = '#27ae60'; }
    if (type === 'error') { icon = '❌'; borderColor = '#e74c3c'; }
    if (type === 'warning') { icon = '⚠️'; borderColor = '#f1c40f'; }

    toast.style.borderLeft = '6px solid ' + borderColor;
    toast.innerHTML = '<span style="font-size: 1.2em; flex-shrink: 0;">' + icon + '</span>' +
        '<span style="font-weight: 600; color: #2c3e50; word-break: break-word;">' + message + '</span>';

    container.appendChild(toast);

    setTimeout(() => { toast.style.transform = 'translateX(0)'; toast.style.opacity = '1'; }, 10);
    setTimeout(() => {
        toast.style.transform = 'translateX(120%)'; toast.style.opacity = '0';
        setTimeout(() => { toast.remove(); }, 400);
    }, 3000);
}

// --- 1. KIỂM TRA ĐĂNG NHẬP & HIỂN THỊ MENU ĐỒNG BỘ ---
function checkAuth() {
    const userStr = localStorage.getItem('user');
    const token = localStorage.getItem('token');

    if (!userStr || !token) {
        showToast("Vui lòng đăng nhập để xem lịch sử mua hàng!", "warning");
        setTimeout(() => { window.location.href = 'login.html'; }, 1500);
        return null;
    }

    const user = JSON.parse(userStr);
    const headerActions = document.querySelector('.header-actions');

    if (headerActions) {
        // Bơm CSS ép cứng cấu trúc (Xử lý menu ngang trên desktop và dropdown trên mobile)
        if (!document.getElementById('dynamic-menu-styles')) {
            const style = document.createElement('style');
            style.id = 'dynamic-menu-styles';
            style.innerHTML = `
                .header-container { display: flex !important; flex-direction: row !important; justify-content: space-between !important; align-items: center !important; flex-wrap: nowrap !important; }
                .header-actions { display: flex !important; align-items: center !important; position: relative !important; gap: 15px !important; }
                .menu-desktop-items { display: flex !important; align-items: center !important; gap: 12px !important; }
                .hamburger-btn { display: none !important; background: none; border: none; font-size: 28px; cursor: pointer; color: #333; }
                
                @media (max-width: 768px) {
                    .hamburger-btn { display: block !important; }
                    .user-greeting { display: none !important; } 
                    .menu-desktop-items {
                        display: none !important; 
                        position: absolute !important;
                        top: 50px !important; right: 0 !important;
                        background: white !important;
                        flex-direction: column !important;
                        padding: 20px !important;
                        border-radius: 15px !important;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important;
                        min-width: 220px !important;
                        z-index: 9999 !important;
                        gap: 15px !important;
                        border: 1px solid #f0f0f0 !important;
                    }
                    .menu-desktop-items.show { display: flex !important; }
                    .menu-desktop-items > * { width: 100% !important; text-align: center !important; margin: 0 !important; }
                }
            `;
            document.head.appendChild(style);
        }

        const greetingHTML = `<span class="user-greeting" style="font-size: 0.95em; color: #333; white-space: nowrap;">Xin chào, <b>${user.name}</b></span>`;

        // Nút Về Trang chủ
        const homeBtn = `<a href="index.html" style="text-decoration: none; padding: 8px 12px; border-radius: 8px; background: #f8f9fa; color: #007bff; border: 1px solid #e1e1e1; font-size: 0.9em; font-weight: bold; white-space: nowrap;">🏠 Trang chủ</a>`;

        // Nút Giỏ hàng (Blue Button) - Nằm trên Đăng xuất
        const cartCount = (JSON.parse(localStorage.getItem('cart')) || []).reduce((sum, i) => sum + i.quantity, 0);
        const cartHTML = `<a href="index.html" style="text-decoration: none; padding: 10px 18px; border-radius: 10px; background: #007bff; color: white; font-weight: bold; font-size: 0.9em; box-shadow: 0 3px 10px rgba(0,123,255,0.2); white-space: nowrap;">🛒 Giỏ hàng (<span id="header-cart-count">${cartCount}</span>)</a>`;

        // Chữ Đăng xuất (Red Text) - Nằm dưới cùng
        const logoutBtn = `<a href="#" onclick="logout()" style="color: #dc3545; font-weight: bold; text-decoration: none; font-size: 0.95em; padding: 10px 0; display: block; white-space: nowrap;">Đăng xuất</a>`;

        headerActions.innerHTML = `
            ${greetingHTML}
            <button class="hamburger-btn" onclick="toggleMobileMenu()">☰</button>
            <div class="menu-desktop-items" id="nav-menu-items">
                ${homeBtn}
                ${cartHTML}
                ${logoutBtn}
            </div>
        `;
    }

    return { user, token };
}

window.toggleMobileMenu = function () {
    const menu = document.getElementById('nav-menu-items');
    if (menu) menu.classList.toggle('show');
};

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    showToast("Đã đăng xuất tài khoản!", "success");
    setTimeout(() => { window.location.href = 'index.html'; }, 1000);
}

// --- 2. LẤY DỮ LIỆU ĐƠN HÀNG TỪ BACKEND ---
async function loadMyOrders() {
    const authData = checkAuth();
    if (!authData) return;

    try {
        const res = await fetch('http://localhost:3000/api/orders/me', {
            headers: { 'Authorization': `Bearer ${authData.token}` }
        });

        if (!res.ok) throw new Error("Không thể tải danh sách đơn hàng.");

        const orders = await res.json();
        const tbody = document.getElementById('history-list');
        tbody.innerHTML = '';

        if (orders.length === 0) {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: #777; padding: 20px;">Bạn chưa có đơn hàng nào!</td></tr>`;
            return;
        }

        orders.forEach(o => {
            const dateStr = new Date(o.created_at).toLocaleString('vi-VN');
            let statusHTML = '';
            if (o.status === 'pending') statusHTML = `<span class="status-badge status-pending" style="background:#ffc107; padding:4px 8px; border-radius:4px; font-size:0.85em;">Chờ xử lý</span>`;
            else if (o.status === 'shipping') statusHTML = `<span class="status-badge status-shipping" style="background:#17a2b8; color:white; padding:4px 8px; border-radius:4px; font-size:0.85em;">Đang giao</span>`;
            else if (o.status === 'done') statusHTML = `<span class="status-badge status-done" style="background:#28a745; color:white; padding:4px 8px; border-radius:4px; font-size:0.85em;">Hoàn thành</span>`;

            tbody.innerHTML += `
                <tr>
                    <td><b>#${o.id}</b></td>
                    <td>${dateStr}</td>
                    <td>
                        <b>${o.receiver_name}</b><br>
                        <small>📞 ${o.phone}</small><br>
                        <small>📍 ${o.address}</small>
                    </td>
                    <td><b style="color: #dc3545;">${o.total}$</b></td>
                    <td>${statusHTML}</td>
                    <td>
                        <button onclick="showOrderDetail(${o.id})" style="background: #007bff; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; font-weight: bold;">🔍 Chi tiết</button>
                    </td>
                </tr>
            `;
        });
    } catch (err) {
        showToast(err.message, "error");
    }
}

// --- 3. HIỂN THỊ CHI TIẾT ĐƠN HÀNG ---
async function showOrderDetail(orderId) {
    const authData = JSON.parse(localStorage.getItem('user'));
    const token = localStorage.getItem('token');

    try {
        const res = await fetch(`http://localhost:3000/api/orders/${orderId}`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!res.ok) throw new Error("Lỗi tải chi tiết đơn hàng.");

        const data = await res.json();

        document.getElementById('detail-order-id').innerText = '#' + data.id;
        document.getElementById('detail-receiver').innerText = data.receiver_name;
        document.getElementById('detail-phone').innerText = data.phone;
        document.getElementById('detail-address').innerText = data.address;
        document.getElementById('detail-date').innerText = new Date(data.created_at).toLocaleString('vi-VN');
        document.getElementById('detail-total').innerText = data.total + '$';

        const tbody = document.getElementById('detail-items-list');
        tbody.innerHTML = '';

        data.items.forEach(item => {
            const itemTotal = item.quantity * item.price_at_time;
            tbody.innerHTML += `
                <tr>
                    <td><b>${item.name}</b></td>
                    <td><img src="${item.image_url}" width="50" style="border-radius:4px;"></td>
                    <td>${item.quantity}</td>
                    <td>${item.price_at_time}$</td>
                    <td><b style="color: #28a745;">${itemTotal}$</b></td>
                </tr>
            `;
        });

        document.getElementById('order-detail-modal').style.display = 'flex';
    } catch (err) {
        showToast(err.message, "error");
    }
}

function closeDetailModal() {
    document.getElementById('order-detail-modal').style.display = 'none';
}

// Khởi chạy
loadMyOrders();