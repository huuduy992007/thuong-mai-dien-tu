// --- 0. HỆ THỐNG THÔNG BÁO TOAST ---
function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.position = 'fixed';
        container.style.top = '20px';
        container.style.right = '20px';
        container.style.zIndex = '9999';
        document.body.prepend(container);
    }

    const toast = document.createElement('div');
    toast.style.background = '#fff';
    toast.style.minWidth = '280px';
    toast.style.padding = '15px 20px';
    toast.style.borderRadius = '8px';
    toast.style.boxShadow = '0 5px 15px rgba(0,0,0,0.15)';
    toast.style.marginBottom = '12px';
    toast.style.display = 'flex';
    toast.style.alignItems = 'center';
    toast.style.gap = '12px';
    toast.style.transition = 'all 0.4s ease';
    toast.style.transform = 'translateX(120%)';
    toast.style.opacity = '0';

    let icon = '🔔';
    let borderColor = '#3498db';
    if (type === 'success') { icon = '✅'; borderColor = '#27ae60'; }
    if (type === 'error') { icon = '❌'; borderColor = '#e74c3c'; }
    if (type === 'warning') { icon = '⚠️'; borderColor = '#f1c40f'; }

    toast.style.borderLeft = '6px solid ' + borderColor;
    toast.innerHTML = `<span style="font-size: 1.2em;">${icon}</span>` +
        `<span style="font-weight: 600; color: #2c3e50;">${message}</span>`;

    container.appendChild(toast);

    setTimeout(() => { toast.style.transform = 'translateX(0)'; toast.style.opacity = '1'; }, 10);
    setTimeout(() => {
        toast.style.transform = 'translateX(120%)'; toast.style.opacity = '0';
        setTimeout(() => { toast.remove(); }, 400);
    }, 3000);
}

// --- HÀM NÉN ẢNH TỰ ĐỘNG ---
// Đảm bảo dung lượng ảnh không quá lớn khi lưu vào Database
const compressImage = (file, maxWidth = 400, quality = 0.7) => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target.result;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > maxWidth) {
                    height = (maxWidth / width) * height;
                    width = maxWidth;
                }
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
        };
        reader.onerror = error => reject(error);
    });
};

// --- KIỂM TRA ĐĂNG NHẬP ---
const token = localStorage.getItem('token');
if (!token) { window.location.href = 'login.html'; }

// --- 1. TẢI THÔNG TIN CÁ NHÂN ---
async function loadProfile() {
    try {
        const res = await fetch('http://localhost:3000/api/user/profile', {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!res.ok) throw new Error();
        const data = await res.json();

        // Điền dữ liệu vào form
        document.getElementById('user-name').value = data.name;
        document.getElementById('user-email').innerText = data.email;
        document.getElementById('user-balance').innerText = (data.balance || 0) + '$';

        if (data.avatar) {
            document.getElementById('display-avatar').src = data.avatar;
        }

        renderHeaderMenu(data);
    } catch (err) {
        showToast("Không thể tải hồ sơ người dùng", "error");
    }
}

// --- 2. RENDER MENU HEADER ĐỒNG BỘ ---
function renderHeaderMenu(user) {
    const headerActions = document.querySelector('.header-actions');
    if (!headerActions) return;

    // Ép cứng CSS cho menu nội tuyến
    if (!document.getElementById('profile-menu-styles')) {
        const style = document.createElement('style');
        style.id = 'profile-menu-styles';
        style.innerHTML = `
            .header-container { display: flex !important; justify-content: space-between !important; align-items: center !important; }
            .header-actions { display: flex !important; align-items: center !important; gap: 15px !important; position: relative !important; }
            .menu-desktop-items { display: flex !important; align-items: center !important; gap: 12px !important; }
            .hamburger-btn { display: none !important; background: none; border: none; font-size: 28px; cursor: pointer; color: #333; }
            
            .header-avatar-link img { 
                width: 38px; height: 38px; border-radius: 50%; object-fit: cover; 
                border: 2px solid #007bff; cursor: pointer; transition: 0.2s;
            }
            .header-avatar-link img:hover { transform: scale(1.1); }

            @media (max-width: 768px) {
                .hamburger-btn { display: block !important; }
                .user-greeting { display: none !important; }
                .menu-desktop-items {
                    display: none !important; position: absolute !important;
                    top: 50px !important; right: 0 !important;
                    background: white !important; flex-direction: column !important;
                    padding: 20px !important; border-radius: 12px !important;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important;
                    min-width: 200px !important; z-index: 9999 !important; gap: 12px !important;
                }
                .menu-desktop-items.show { display: flex !important; }
                .menu-desktop-items > * { width: 100% !important; text-align: center !important; }
            }
        `;
        document.head.appendChild(style);
    }

    const greetingHTML = `<span class="user-greeting">Xin chào, <b>${user.name}</b></span>`;
    const avatarHTML = `<a href="profile.html" class="header-avatar-link"><img src="${user.avatar || 'https://placehold.co/100x100?text=👤'}" title="Hồ sơ cá nhân"></a>`;

    const homeBtn = `<a href="index.html" style="text-decoration: none; padding: 8px 12px; border-radius: 8px; background: #f8f9fa; color: #007bff; border: 1px solid #e1e1e1; font-size: 0.9em; font-weight: bold;">🏠 Trang chủ</a>`;

    let adminBtn = '';
    if (user.role === 'admin') {
        adminBtn = `<a href="admin.html" style="text-decoration: none; padding: 8px 12px; border-radius: 8px; background: #f8f9fa; color: #28a745; border: 1px solid #e1e1e1; font-size: 0.9em; font-weight: bold;">⚙️ Admin</a>`;
    }

    const historyBtn = `<a href="history.html" style="text-decoration: none; padding: 8px 12px; border-radius: 8px; background: #f8f9fa; color: #17a2b8; border: 1px solid #e1e1e1; font-size: 0.9em; font-weight: bold;">📦 Đơn hàng</a>`;
    const logoutBtn = `<a href="#" onclick="logout()" style="color: #dc3545; font-weight: bold; text-decoration: none; font-size: 0.95em; padding: 10px 0;">Đăng xuất</a>`;

    headerActions.innerHTML = `
        ${greetingHTML}
        ${avatarHTML}
        <button class="hamburger-btn" onclick="toggleMobileMenu()">☰</button>
        <div class="menu-desktop-items" id="nav-menu-items">
            <a href="profile.html" class="mobile-only" style="display:none; font-weight:bold; color:#007bff; border-bottom:1px solid #eee; padding-bottom:10px;">👤 Hồ sơ cá nhân</a>
            ${homeBtn}
            ${adminBtn}
            ${historyBtn}
            ${logoutBtn}
        </div>
    `;
}

window.toggleMobileMenu = function () {
    const menu = document.getElementById('nav-menu-items');
    if (menu) menu.classList.toggle('show');
};

// --- 3. XỬ LÝ CHỌN ẢNH ĐẠI DIỆN ---
document.getElementById('avatar-file').addEventListener('change', async (e) => {
    if (e.target.files.length > 0) {
        showToast("Đang xử lý hình ảnh...", "info");
        try {
            const base64 = await compressImage(e.target.files[0]);
            document.getElementById('display-avatar').src = base64;
            showToast("Đã nén ảnh thành công!", "success");
        } catch (err) {
            showToast("Lỗi xử lý tệp ảnh", "error");
        }
    }
});

// --- 4. LƯU THAY ĐỔI HỒ SƠ ---
document.getElementById('profile-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('btn-save-profile');

    try {
        btn.disabled = true;
        btn.innerText = "Đang cập nhật...";

        const payload = {
            name: document.getElementById('user-name').value,
            avatar: document.getElementById('display-avatar').src,
            new_password: document.getElementById('user-new-password').value
        };

        const res = await fetch('http://localhost:3000/api/user/update', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            showToast("Cập nhật hồ sơ thành công!", "success");

            // Cập nhật lại tên và ảnh trong LocalStorage để các trang khác thấy ngay
            const userData = JSON.parse(localStorage.getItem('user'));
            userData.name = payload.name;
            userData.avatar = payload.avatar;
            localStorage.setItem('user', JSON.stringify(userData));

            setTimeout(() => window.location.reload(), 1500);
        } else {
            const err = await res.json();
            showToast("Lỗi: " + err.error, "error");
        }
    } catch (err) {
        showToast("Không thể kết nối máy chủ", "error");
    } finally {
        btn.disabled = false;
        btn.innerText = "Lưu thay đổi";
    }
});

// --- 5. NẠP TIỀN VÀO VÍ (GIẢ LẬP) ---
async function topupWallet() {
    const amount = prompt("Nhập số tiền bạn muốn nạp vào ví ($):", "100");
    if (!amount || isNaN(amount) || parseFloat(amount) <= 0) {
        if (amount !== null) showToast("Số tiền nạp không hợp lệ", "warning");
        return;
    }

    try {
        const res = await fetch('http://localhost:3000/api/user/topup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ amount: parseFloat(amount) })
        });

        if (res.ok) {
            showToast(`Đã nạp ${amount}$ thành công!`, "success");
            loadProfile(); // Tải lại dữ liệu để cập nhật số dư hiển thị
        } else {
            showToast("Nạp tiền thất bại, vui lòng thử lại sau", "error");
        }
    } catch (err) {
        showToast("Lỗi hệ thống nạp tiền", "error");
    }
}

function logout() {
    localStorage.clear();
    window.location.href = 'index.html';
}

// Khởi chạy
loadProfile();